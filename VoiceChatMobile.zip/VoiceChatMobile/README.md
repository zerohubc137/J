# VoiceChat Mobile 🎮

VoiceChat สำหรับ Android — ใช้ **VoiceChat.dll เดิม** แต่เปลี่ยน audio backend ให้รองรับ Android

## ปัญหาเดิม
| ไฟล์ | ปัญหาบน Android |
|------|----------------|
| `portaudio.dll` | Windows x64 native — Android โหลดไม่ได้ |
| `rnnoise.dll` | Windows x64 native — Android โหลดไม่ได้ |

## วิธีแก้
สร้าง `PortAudioSharp.dll` และ `RNNoise.NET.dll` ใหม่ที่มี API เหมือนเดิมทุก method แต่:
- **PortAudioSharp**: ใช้ `Android.Media.AudioRecord` + `AudioTrack` ผ่าน Reflection
- **RNNoise.NET**: Pure C# noise gate (ไม่ต้องพึ่ง native DLL)
- **PC backward-compat**: ยังพยายามโหลด native DLL บน Windows อยู่ (ถ้ามี)

`VoiceChat.dll` ไม่ต้องแตะเลยแม้แต่ byte เดียว ✅

## วิธีได้ไฟล์ (ทำบนมือถือได้!)

1. สร้าง GitHub repository ใหม่
2. อัพโหลดไฟล์จาก zip นี้ทั้งหมด
3. ไปที่ **Actions** tab → GitHub จะ build อัตโนมัติ
4. ดาวน์โหลด `VoiceChat-Mobile.zip` จาก **Releases**
5. ติดตั้งตามขั้นตอนใน Release notes

## โครงสร้างไฟล์หลังติดตั้ง
```
Mods/VoiceChat/
├── VoiceChat.dll        ✅ ของเดิม (Stardew mod logic)
├── Concentus.dll        ✅ ของเดิม (Opus audio codec, pure .NET)
├── PortAudioSharp.dll   🆕 Android-compatible audio I/O
├── RNNoise.NET.dll      🆕 Pure C# noise suppression
├── manifest.json
├── i18n/default.json
└── assets/sprites/ui.png
```
