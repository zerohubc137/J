using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;

namespace PortAudioSharp
{
    /// <summary>
    /// Android-compatible PortAudio static API.
    /// ตรวจจับ platform ที่ runtime:
    ///   - PC  → พยายามโหลด portaudio native ผ่าน DllImport fallback
    ///   - Android → สร้าง virtual devices แทน (ใช้ Android.Media ใน Stream class)
    /// </summary>
    public static class PortAudio
    {
        // ── Platform detection ─────────────────────────────────────────────
        internal static readonly bool IsAndroid = DetectAndroid();
        internal static readonly bool IsPC      = !IsAndroid;

        private static bool DetectAndroid()
        {
            // หลายวิธีตรวจว่าอยู่บน Android
            if (System.IO.File.Exists("/system/build.prop"))          return true;
            if (System.Environment.GetEnvironmentVariable("ANDROID_ROOT") != null) return true;
            try
            {
                // ถ้าโหลด Mono.Android.dll ได้ = Android
                Assembly.Load("Mono.Android");
                return true;
            }
            catch { return false; }
        }

        // ── Virtual device list for Android ────────────────────────────────
        private static readonly DeviceInfoData[] _androidDevices = new[]
        {
            new DeviceInfoData
            {
                structVersion         = 2,
                name                  = "Android Default Input",
                hostApi               = 0,
                maxInputChannels      = 1,
                maxOutputChannels     = 0,
                defaultLowInputLatency  = 0.01,
                defaultHighInputLatency = 0.05,
                defaultSampleRate     = 48000,
            },
            new DeviceInfoData
            {
                structVersion         = 2,
                name                  = "Android Default Output",
                hostApi               = 0,
                maxInputChannels      = 0,
                maxOutputChannels     = 2,
                defaultLowOutputLatency  = 0.01,
                defaultHighOutputLatency = 0.05,
                defaultSampleRate     = 48000,
            },
        };

        // ── PC native fallback (P/Invoke, will fail gracefully on Android) ─
        private static bool _nativeAvailable;

        // ── Init/Terminate ──────────────────────────────────────────────────
        public static void Pa_Initialize()
        {
            if (IsAndroid) return;   // Android ไม่ต้องทำอะไร
            try { NativeInit(); _nativeAvailable = true; }
            catch { _nativeAvailable = false; }
        }

        public static void Pa_Terminate()
        {
            if (IsAndroid || !_nativeAvailable) return;
            try { NativeTerminate(); } catch { }
        }

        // ── Device enumeration ──────────────────────────────────────────────
        public static int Pa_GetDeviceCount()
        {
            if (IsAndroid) return _androidDevices.Length;
            if (!_nativeAvailable) return 2;
            try { return NativeGetDeviceCount(); } catch { return 2; }
        }

        public static int Pa_GetDefaultInputDevice()
        {
            if (IsAndroid || !_nativeAvailable) return 0;
            try { return NativeGetDefaultInputDevice(); } catch { return 0; }
        }

        public static int Pa_GetDefaultOutputDevice()
        {
            if (IsAndroid || !_nativeAvailable) return 1;
            try { return NativeGetDefaultOutputDevice(); } catch { return 1; }
        }

        public static DeviceInfoData Pa_GetDeviceInfo(int device)
        {
            if (IsAndroid)
            {
                if (device >= 0 && device < _androidDevices.Length)
                    return _androidDevices[device];
                return _androidDevices[0];
            }
            if (!_nativeAvailable)
                return device == 0 ? _androidDevices[0] : _androidDevices[1];
            try { return NativeGetDeviceInfo(device); } catch { return _androidDevices[0]; }
        }

        public static string Pa_GetDeviceName(int device)
            => Pa_GetDeviceInfo(device).name ?? $"Device {device}";

        public static IEnumerable<(int Index, DeviceInfoData Info)> GetInputDevices()
        {
            int count = Pa_GetDeviceCount();
            for (int i = 0; i < count; i++)
            {
                var info = Pa_GetDeviceInfo(i);
                if (info.maxInputChannels > 0)
                    yield return (i, info);
            }
        }

        public static IEnumerable<(int Index, DeviceInfoData Info)> GetOutputDevices()
        {
            int count = Pa_GetDeviceCount();
            for (int i = 0; i < count; i++)
            {
                var info = Pa_GetDeviceInfo(i);
                if (info.maxOutputChannels > 0)
                    yield return (i, info);
            }
        }

        // ── Version ─────────────────────────────────────────────────────────
        public static string Pa_GetVersion()           => "Android-compat 1.0";
        public static VersionInfo Pa_GetVersionInfo()  => new() { versionMajor=1, versionText="Android-compat 1.0" };
        public static string Pa_GetErrorText(int err)  => $"Error {err}";

        // ── Stream factory ───────────────────────────────────────────────────
        // (Stream class handles PC vs Android internally)

        // ── Helpers ──────────────────────────────────────────────────────────
        public static void Pa_Sleep(int msec)
        {
            System.Threading.Thread.Sleep(Math.Max(1, msec));
        }

        // ── PC native P/Invokes (not called on Android) ──────────────────────
        private const string LIB = "portaudio";

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_Initialize")]
        private static extern int NativeInit();

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_Terminate")]
        private static extern int NativeTerminate();

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_GetDeviceCount")]
        private static extern int NativeGetDeviceCount();

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_GetDefaultInputDevice")]
        private static extern int NativeGetDefaultInputDevice();

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_GetDefaultOutputDevice")]
        private static extern int NativeGetDefaultOutputDevice();

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "Pa_GetDeviceInfo")]
        private static extern IntPtr NativeGetDeviceInfoPtr(int device);

        private static DeviceInfoData NativeGetDeviceInfo(int device)
        {
            var ptr = NativeGetDeviceInfoPtr(device);
            if (ptr == IntPtr.Zero) return _androidDevices[0];
            return Marshal.PtrToStructure<DeviceInfoData>(ptr);
        }
    }
}
