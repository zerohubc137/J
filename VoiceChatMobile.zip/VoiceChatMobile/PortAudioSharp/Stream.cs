using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace PortAudioSharp
{
    /// <summary>
    /// Replacement Stream ที่ทำงานบน Android โดยใช้ Android.Media ผ่าน Reflection
    /// และบน PC ใช้ native portaudio เหมือนเดิม
    ///
    /// รูปแบบการทำงาน:
    ///   INPUT stream  → Android AudioRecord → callback(input, null)
    ///   OUTPUT stream → callback(null, output) → Android AudioTrack
    /// </summary>
    public class Stream : IDisposable
    {
        // ── Callback delegate (เหมือน PortAudioSharp เดิม 100%) ───────────────
        public delegate StreamCallbackResult Callback(
            IntPtr input, IntPtr output,
            uint   frameCount,
            ref StreamCallbackTimeInfo timeInfo,
            StreamCallbackFlags statusFlags,
            IntPtr userData);

        // ── Fields ──────────────────────────────────────────────────────────
        private readonly StreamParameters? _inputParams;
        private readonly StreamParameters? _outputParams;
        private readonly double            _sampleRate;
        private readonly uint              _framesPerBuffer;
        private readonly StreamFlags       _streamFlags;
        private readonly Callback          _callback;
        private readonly IntPtr            _userData;

        private volatile bool _active;
        private volatile bool _stopped = true;
        private Thread?       _thread;
        private Action?       _finishedCallback;

        // Android audio objects (via reflection to avoid hard deps)
        private object? _audioRecord;   // Android.Media.AudioRecord
        private object? _audioTrack;    // Android.Media.AudioTrack

        // PC native stream handle
        private IntPtr _nativeStream = IntPtr.Zero;
        private bool   _nativeMode;

        // ── Constructor ──────────────────────────────────────────────────────
        public Stream(
            StreamParameters? inputParameters,
            StreamParameters? outputParameters,
            double sampleRate,
            uint   framesPerBuffer,
            StreamFlags streamFlags,
            Callback callback,
            IntPtr userData = default)
        {
            _inputParams      = inputParameters;
            _outputParams     = outputParameters;
            _sampleRate       = sampleRate;
            _framesPerBuffer  = framesPerBuffer == 0 ? 960 : framesPerBuffer;
            _streamFlags      = streamFlags;
            _callback         = callback;
            _userData         = userData;

            if (PortAudio.IsPC)
                TryOpenNative();
        }

        // ── PC native open ──────────────────────────────────────────────────
        private void TryOpenNative()
        {
            try
            {
                // Pa_OpenStream wrapper — if it throws we fall back to Android path
                unsafe
                {
                    IntPtr inPtr  = IntPtr.Zero;
                    IntPtr outPtr = IntPtr.Zero;

                    if (_inputParams.HasValue)
                    {
                        var p = _inputParams.Value;
                        inPtr = Marshal.AllocHGlobal(Marshal.SizeOf<StreamParameters>());
                        Marshal.StructureToPtr(p, inPtr, false);
                    }
                    if (_outputParams.HasValue)
                    {
                        var p = _outputParams.Value;
                        outPtr = Marshal.AllocHGlobal(Marshal.SizeOf<StreamParameters>());
                        Marshal.StructureToPtr(p, outPtr, false);
                    }

                    IntPtr streamPtr = IntPtr.Zero;
                    int err = NativePa_OpenStream(
                        ref streamPtr, inPtr, outPtr,
                        _sampleRate, _framesPerBuffer,
                        (uint)_streamFlags,
                        NativeCallback, _userData);

                    if (inPtr  != IntPtr.Zero) Marshal.FreeHGlobal(inPtr);
                    if (outPtr != IntPtr.Zero) Marshal.FreeHGlobal(outPtr);

                    if (err == 0) { _nativeStream = streamPtr; _nativeMode = true; }
                }
            }
            catch { _nativeMode = false; }
        }

        // native callback trampoline
        private StreamCallbackResult NativeCallback(
            IntPtr input, IntPtr output, uint frameCount,
            ref StreamCallbackTimeInfo timeInfo,
            StreamCallbackFlags flags, IntPtr userData)
            => _callback(input, output, frameCount, ref timeInfo, flags, userData);

        // ── Properties ────────────────────────────────────────────────────────
        public bool IsActive   => _active;
        public bool IsStopped  => _stopped;
        public double Time     => DateTime.UtcNow.TimeOfDay.TotalSeconds;
        public double CpuLoad  => 0.0;

        // ── Start ─────────────────────────────────────────────────────────────
        public void Start()
        {
            if (_active) return;

            if (_nativeMode && _nativeStream != IntPtr.Zero)
            {
                int err = NativePa_StartStream(_nativeStream);
                if (err == 0) { _active = true; _stopped = false; return; }
            }

            // Android (or PC fallback): use thread-based audio
            _active  = true;
            _stopped = false;

            if (_inputParams.HasValue)
                StartAndroidCapture();
            else if (_outputParams.HasValue)
                StartAndroidPlayback();
        }

        // ── Stop / Abort ───────────────────────────────────────────────────────
        public void Stop()
        {
            _active = false;
            if (_nativeMode && _nativeStream != IntPtr.Zero)
                try { NativePa_StopStream(_nativeStream); } catch { }
            WaitForThread();
            _stopped = true;
            _finishedCallback?.Invoke();
        }

        public void Abort()
        {
            _active = false;
            if (_nativeMode && _nativeStream != IntPtr.Zero)
                try { NativePa_AbortStream(_nativeStream); } catch { }
            WaitForThread();
            _stopped = true;
        }

        public void Close()
        {
            Stop();
            if (_nativeMode && _nativeStream != IntPtr.Zero)
            {
                try { NativePa_CloseStream(_nativeStream); } catch { }
                _nativeStream = IntPtr.Zero;
            }
            ReleaseAndroidObjects();
        }

        public void SetFinishedCallback(Action cb) => _finishedCallback = cb;

        private void WaitForThread()
        {
            _thread?.Join(2000);
            _thread = null;
        }

        // ── Android capture (INPUT stream) ──────────────────────────────────
        private void StartAndroidCapture()
        {
            _thread = new Thread(CaptureLoop) { IsBackground = true, Name = "PASharp-Capture" };
            _thread.Start();
        }

        private void CaptureLoop()
        {
            int    sampleRate = (int)_sampleRate;
            int    frames     = (int)_framesPerBuffer;
            int    channels   = _inputParams?.channelCount ?? 1;
            float[] buf       = new float[frames * channels];
            int    byteCount  = buf.Length * sizeof(float);

            // Try Android.Media.AudioRecord via reflection
            bool useAndroid = TryInitAudioRecord(sampleRate, channels, frames * channels);

            IntPtr inputPtr  = Marshal.AllocHGlobal(byteCount);
            IntPtr outputPtr = IntPtr.Zero; // input-only stream

            try
            {
                while (_active)
                {
                    if (useAndroid)
                        ReadFromAudioRecord(buf);
                    else
                        // Silence if no audio hardware available
                        Array.Clear(buf, 0, buf.Length);

                    Marshal.Copy(buf, 0, inputPtr, buf.Length);
                    var timeInfo = new StreamCallbackTimeInfo { currentTime = Time };
                    var result = _callback(inputPtr, outputPtr, (uint)frames,
                                           ref timeInfo, StreamCallbackFlags.InputOverflow, _userData);

                    if (result != StreamCallbackResult.Continue)
                        break;
                }
            }
            finally
            {
                Marshal.FreeHGlobal(inputPtr);
                StopAudioRecord();
            }
            _active = false; _stopped = true;
            _finishedCallback?.Invoke();
        }

        // ── Android playback (OUTPUT stream) ──────────────────────────────────
        private void StartAndroidPlayback()
        {
            _thread = new Thread(PlaybackLoop) { IsBackground = true, Name = "PASharp-Playback" };
            _thread.Start();
        }

        private void PlaybackLoop()
        {
            int    sampleRate = (int)_sampleRate;
            int    frames     = (int)_framesPerBuffer;
            int    channels   = _outputParams?.channelCount ?? 1;
            float[] buf       = new float[frames * channels];
            int    byteCount  = buf.Length * sizeof(float);

            bool useAndroid = TryInitAudioTrack(sampleRate, channels);

            IntPtr inputPtr  = IntPtr.Zero; // output-only stream
            IntPtr outputPtr = Marshal.AllocHGlobal(byteCount);

            try
            {
                while (_active)
                {
                    Array.Clear(buf, 0, buf.Length);
                    var timeInfo = new StreamCallbackTimeInfo { currentTime = Time };
                    var result = _callback(inputPtr, outputPtr, (uint)frames,
                                           ref timeInfo, 0, _userData);

                    if (result != StreamCallbackResult.Continue)
                        break;

                    Marshal.Copy(outputPtr, buf, 0, buf.Length);
                    if (useAndroid)
                        WriteToAudioTrack(buf);
                }
            }
            finally
            {
                Marshal.FreeHGlobal(outputPtr);
                StopAudioTrack();
            }
            _active = false; _stopped = true;
            _finishedCallback?.Invoke();
        }

        // ── Android.Media.AudioRecord via reflection ────────────────────────
        private bool TryInitAudioRecord(int sampleRate, int channels, int bufferFrames)
        {
            try
            {
                var asm      = System.Reflection.Assembly.Load("Mono.Android");
                var arType   = asm.GetType("Android.Media.AudioRecord");
                if (arType == null) return false;

                // AudioSource.Mic = 1, ChannelIn.Mono = 16, Encoding.PcmFloat = 4
                // minimum buffer size
                var getMinBuf = arType.GetMethod("GetMinBufferSize",
                    new[] { typeof(int), typeof(int), typeof(int) });
                int minBuf = (int)(getMinBuf?.Invoke(null, new object[]{ sampleRate, 16, 4 }) ?? 3840);
                int bufSize = Math.Max(minBuf, bufferFrames * sizeof(float));

                _audioRecord = Activator.CreateInstance(arType,
                    /*audioSource*/ 1,
                    sampleRate,
                    /*channelMask*/ 16,
                    /*audioFormat*/ 4,   // PcmFloat
                    bufSize);

                // Start recording
                arType.GetMethod("StartRecording")?.Invoke(_audioRecord, null);
                return true;
            }
            catch { return false; }
        }

        private void ReadFromAudioRecord(float[] buf)
        {
            if (_audioRecord == null) return;
            try
            {
                // AudioRecord.Read(float[] audioData, int offsetInFloats, int sizeInFloats, int readMode=0)
                var t = _audioRecord.GetType();
                t.GetMethod("Read", new[]{ typeof(float[]), typeof(int), typeof(int), typeof(int) })
                 ?.Invoke(_audioRecord, new object[]{ buf, 0, buf.Length, 0 });
            }
            catch { Array.Clear(buf, 0, buf.Length); }
        }

        private void StopAudioRecord()
        {
            if (_audioRecord == null) return;
            try
            {
                var t = _audioRecord.GetType();
                t.GetMethod("Stop")?.Invoke(_audioRecord, null);
                (_audioRecord as IDisposable)?.Dispose();
            }
            catch { }
            _audioRecord = null;
        }

        // ── Android.Media.AudioTrack via reflection ─────────────────────────
        private bool TryInitAudioTrack(int sampleRate, int channels)
        {
            try
            {
                var asm    = System.Reflection.Assembly.Load("Mono.Android");
                var atType = asm.GetType("Android.Media.AudioTrack");
                if (atType == null) return false;

                // AudioTrack.GetMinBufferSize(sampleRate, ChannelOut.Mono=4, Encoding.PcmFloat=4)
                var getMinBuf = atType.GetMethod("GetMinBufferSize",
                    new[] { typeof(int), typeof(int), typeof(int) });
                int chOut = channels == 1 ? 4 : 12; // Mono=4, Stereo=12
                int minBuf = (int)(getMinBuf?.Invoke(null, new object[]{ sampleRate, chOut, 4 }) ?? 3840);

                // new AudioTrack(stream=3 [Music], sampleRate, chOut, PcmFloat=4, minBuf*2, MODE_STREAM=1)
                _audioTrack = Activator.CreateInstance(atType,
                    3, sampleRate, chOut, 4, minBuf * 2, 1);

                atType.GetMethod("Play")?.Invoke(_audioTrack, null);
                return true;
            }
            catch { return false; }
        }

        private void WriteToAudioTrack(float[] buf)
        {
            if (_audioTrack == null) return;
            try
            {
                var t = _audioTrack.GetType();
                // AudioTrack.Write(float[] data, int offsetInFloats, int sizeInFloats, WriteMode=0)
                t.GetMethod("Write", new[]{ typeof(float[]), typeof(int), typeof(int), typeof(int) })
                 ?.Invoke(_audioTrack, new object[]{ buf, 0, buf.Length, 0 });
            }
            catch { }
        }

        private void StopAudioTrack()
        {
            if (_audioTrack == null) return;
            try
            {
                var t = _audioTrack.GetType();
                t.GetMethod("Stop")?.Invoke(_audioTrack, null);
                (_audioTrack as IDisposable)?.Dispose();
            }
            catch { }
            _audioTrack = null;
        }

        private void ReleaseAndroidObjects()
        {
            StopAudioRecord();
            StopAudioTrack();
        }

        // ── Dispose ───────────────────────────────────────────────────────────
        public void Dispose()
        {
            Close();
            GC.SuppressFinalize(this);
        }

        // ── PC Native P/Invokes ───────────────────────────────────────────────
        private const string LIB = "portaudio";

        [DllImport(LIB, EntryPoint = "Pa_OpenStream")]
        private static extern int NativePa_OpenStream(
            ref IntPtr stream,
            IntPtr inputParameters, IntPtr outputParameters,
            double sampleRate, uint framesPerBuffer,
            uint streamFlags,
            [MarshalAs(UnmanagedType.FunctionPtr)] Callback streamCallback,
            IntPtr userData);

        [DllImport(LIB, EntryPoint = "Pa_StartStream")]
        private static extern int NativePa_StartStream(IntPtr stream);

        [DllImport(LIB, EntryPoint = "Pa_StopStream")]
        private static extern int NativePa_StopStream(IntPtr stream);

        [DllImport(LIB, EntryPoint = "Pa_AbortStream")]
        private static extern int NativePa_AbortStream(IntPtr stream);

        [DllImport(LIB, EntryPoint = "Pa_CloseStream")]
        private static extern int NativePa_CloseStream(IntPtr stream);
    }
}
