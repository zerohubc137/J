using System;

namespace PortAudioSharp
{
    // ── Enums ──────────────────────────────────────────────────────────────
    [Flags]
    public enum SampleFormat : uint
    {
        Float32    = 0x00000001,
        Int32      = 0x00000002,
        Int24      = 0x00000004,
        Int16      = 0x00000008,
        Int8       = 0x00000010,
        UInt8      = 0x00000020,
        NonInterleaved = 0x80000000,
    }

    public enum StreamCallbackResult
    {
        Continue = 0,
        Complete = 1,
        Abort    = 2,
    }

    [Flags]
    public enum StreamCallbackFlags : uint
    {
        InputUnderflow  = 0x00000001,
        InputOverflow   = 0x00000002,
        OutputUnderflow = 0x00000004,
        OutputOverflow  = 0x00000008,
        PrimingOutput   = 0x00000010,
    }

    [Flags]
    public enum StreamFlags : uint
    {
        NoFlag                              = 0,
        ClipOff                             = 0x00000001,
        DitherOff                           = 0x00000002,
        NeverDropInput                      = 0x00000004,
        PrimeOutputBuffersUsingStreamCallback = 0x00000008,
        PlatformSpecificFlags               = 0xFFFF0000,
    }

    // ── Structs ────────────────────────────────────────────────────────────
    public struct StreamCallbackTimeInfo
    {
        public double inputBufferAdcTime;
        public double currentTime;
        public double outputBufferDacTime;
    }

    public struct StreamParameters
    {
        public int          device;
        public int          channelCount;
        public SampleFormat sampleFormat;
        public double       suggestedLatency;
        public IntPtr       hostApiSpecificStreamInfo;

        public StreamParameters(int device, int channelCount,
                                SampleFormat fmt, double latency)
        {
            this.device                    = device;
            this.channelCount              = channelCount;
            this.sampleFormat              = fmt;
            this.suggestedLatency          = latency;
            this.hostApiSpecificStreamInfo = IntPtr.Zero;
        }
    }

    public struct DeviceInfoData
    {
        public int    structVersion;
        public string name;
        public int    hostApi;
        public int    maxInputChannels;
        public int    maxOutputChannels;
        public double defaultLowInputLatency;
        public double defaultLowOutputLatency;
        public double defaultHighInputLatency;
        public double defaultHighOutputLatency;
        public double defaultSampleRate;
    }

    public struct VersionInfo
    {
        public int    versionMajor;
        public int    versionMinor;
        public int    versionSubMinor;
        public string versionControlRevision;
        public string versionText;
    }

    // ── Exception ──────────────────────────────────────────────────────────
    public class PortAudioException : Exception
    {
        public int ErrorCode { get; }
        public PortAudioException(string message, int code = -1)
            : base(message) { ErrorCode = code; }
    }
}
