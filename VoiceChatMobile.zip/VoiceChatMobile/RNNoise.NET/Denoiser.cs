using System;

namespace RNNoise.NET
{
    /// <summary>
    /// Android-compatible Denoiser — implements the same API as RNNoise.NET
    /// แต่ใช้ pure C# noise gate แทน native rnnoise.dll
    ///
    /// บน PC: พยายามโหลด rnnoise native → ถ้าไม่มีใช้ noise gate
    /// บน Android: ใช้ noise gate เสมอ (Windows DLL ใช้ไม่ได้)
    /// </summary>
    public class Denoiser : IDisposable
    {
        // ── ตรงกับ RNNoise.NET เดิม 100% ───────────────────────────────────
        public const int FRAME_SIZE = 480;

        // ── Noise gate parameters ──────────────────────────────────────────
        // ปรับค่าเหล่านี้ตามความต้องการ
        private const float VAD_THRESHOLD   = 0.02f;  // ระดับ RMS ที่ถือว่ามีเสียง
        private const float ATTACK_COEFF    = 0.90f;  // ความเร็วเปิด gate
        private const float RELEASE_COEFF   = 0.98f;  // ความเร็วปิด gate
        private const float NOISE_REDUCTION = 0.15f;  // ลดเสียงรบกวน (0=ไม่ลด, 1=เงียบ)

        // ── State ──────────────────────────────────────────────────────────
        private float _gateLevel  = 0f;
        private float _noiseFloor = 0f;
        private bool  _disposed;

        // ── PC native fallback ─────────────────────────────────────────────
        private static readonly bool _isAndroid = IsAndroid();
        private IntPtr _nativeState = IntPtr.Zero;
        private bool   _nativeOk;

        public Denoiser()
        {
            if (!_isAndroid)
                TryLoadNative();
        }

        private static bool IsAndroid()
        {
            if (System.IO.File.Exists("/system/build.prop")) return true;
            if (System.Environment.GetEnvironmentVariable("ANDROID_ROOT") != null) return true;
            try { System.Reflection.Assembly.Load("Mono.Android"); return true; }
            catch { return false; }
        }

        private void TryLoadNative()
        {
            try
            {
                _nativeState = NativeCreate(IntPtr.Zero);
                _nativeOk = _nativeState != IntPtr.Zero;
            }
            catch { _nativeOk = false; }
        }

        // ── Main API ────────────────────────────────────────────────────────
        /// <summary>
        /// Denoise a frame of FRAME_SIZE (480) float samples.
        /// Modifies pcm in-place. Returns VAD probability (0–1).
        /// </summary>
        public unsafe float Denoise(Span<float> pcm)
        {
            if (pcm.Length < FRAME_SIZE)
                return 0f;

            // PC native path
            if (_nativeOk && _nativeState != IntPtr.Zero)
            {
                fixed (float* p = pcm)
                {
                    try { return NativeProcessFrame(_nativeState, p, p); }
                    catch { _nativeOk = false; }
                }
            }

            // Pure C# noise gate path (Android + PC fallback)
            return PureCsNoisegate(pcm);
        }

        private float PureCsNoisegate(Span<float> pcm)
        {
            // ── RMS calculation ─────────────────────────────────────────────
            float sumSq = 0f;
            for (int i = 0; i < FRAME_SIZE; i++)
                sumSq += pcm[i] * pcm[i];
            float rms = MathF.Sqrt(sumSq / FRAME_SIZE);

            // ── Noise floor estimation ──────────────────────────────────────
            _noiseFloor = _noiseFloor * 0.999f + rms * 0.001f;
            float snr   = _noiseFloor > 0 ? rms / (_noiseFloor + 1e-9f) : 1f;

            // ── Gate envelope ───────────────────────────────────────────────
            bool voiced = rms > VAD_THRESHOLD;
            _gateLevel = voiced
                ? _gateLevel * ATTACK_COEFF   + 1f * (1f - ATTACK_COEFF)
                : _gateLevel * RELEASE_COEFF  + 0f * (1f - RELEASE_COEFF);

            float vad = voiced ? MathF.Min(1f, snr * 0.5f) : 0f;

            // ── Apply gate + subtle noise reduction ─────────────────────────
            float gain = _gateLevel * (1f - NOISE_REDUCTION) + NOISE_REDUCTION;
            for (int i = 0; i < FRAME_SIZE; i++)
                pcm[i] *= gain;

            return vad;
        }

        // ── Dispose ─────────────────────────────────────────────────────────
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            if (_nativeOk && _nativeState != IntPtr.Zero)
            {
                try { NativeDestroy(_nativeState); } catch { }
                _nativeState = IntPtr.Zero;
            }
            GC.SuppressFinalize(this);
        }

        // ── PC Native P/Invokes ──────────────────────────────────────────────
        private const string LIB = "rnnoise";

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "rnnoise_create")]
        private static extern IntPtr NativeCreate(IntPtr model);

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "rnnoise_destroy")]
        private static extern void NativeDestroy(IntPtr state);

        [System.Runtime.InteropServices.DllImport(LIB, EntryPoint = "rnnoise_process_frame")]
        private static unsafe extern float NativeProcessFrame(IntPtr state, float* output, float* input);
    }
}
